<input type="hidden" class="msg_opps" value="<?php echo trans('oops'); ?>">
<input type="hidden" class="msg_error" value="<?php echo trans('error'); ?>">
<input type="hidden" class="msg_success" value="<?php echo trans('success'); ?>">
<input type="hidden" class="msg_sorry" value="<?php echo trans('sorry'); ?>">
<input type="hidden" class="msg_yes" value="<?php echo trans('yes'); ?>">
<input type="hidden" class="msg_congratulations" value="<?php echo trans('congratulations'); ?>">
<input type="hidden" class="msg_something_wrong" value="<?php echo trans('something-wrong'); ?>">
<input type="hidden" class="msg_try_again" value="<?php echo trans('try-again'); ?>">
<input type="hidden" class="msg_password_reset_success_msg" value="<?php echo trans('password-reset-success-msg'); ?>">
<input type="hidden" class="msg_confirm_pass_not_match_msg" value="<?php echo trans('confirm-pass-not-match-msg'); ?>">
<input type="hidden" class="msg_old_password_doesnt_match" value="<?php echo trans('old-password-doesnt-match'); ?>">
<input type="hidden" class="msg_inserted" value="<?php echo trans('added-successfully'); ?>">
<input type="hidden" class="msg_made_changes_not_saved" value="<?php echo trans('made-changes-not-saved'); ?>">
<input type="hidden" class="msg_no_data_founds" value="<?php echo trans('data-not-found'); ?>">
<input type="hidden" class="msg_del_success" value="<?php echo trans('deleted-successfully'); ?>">
<input type="hidden" class="msg_account_suspend_msg" value="<?php echo trans('account-suspend-msg'); ?>">
<input type="hidden" class="msg_are_you_sure" value="<?php echo trans('are-you-sure'); ?>">
<input type="hidden" class="msg_get_started" value="<?php echo trans('get-started'); ?>">
<input type="hidden" class="msg_not_recover_file" value="<?php echo trans('not-recover-file'); ?>">
<input type="hidden" class="msg_deleted_successfully" value="<?php echo trans('deleted-successfully'); ?>">
<input type="hidden" class="msg_data_limit_over" value="<?php echo trans('data-limit-over'); ?>">
<input type="hidden" class="msg_email_exist" value="<?php echo trans('email-exist'); ?>">
<input type="hidden" class="msg_recaptcha_is_required" value="<?php echo trans('recaptcha-is-required'); ?>">

<input type="hidden" class="msg_not_active" value="<?php echo trans('account-not-active'); ?>">
<input type="hidden" class="msg_signin" value="<?php echo trans('sign-in'); ?>">
<input type="hidden" class="msg_signing_in" value="<?php echo trans('signing-in'); ?>">

<input type="hidden" class="msg_wrong_access" value="<?php echo trans('incorrect-username-or-password'); ?>">
<input type="hidden" class="msg_email_not_verified" value="<?php echo trans('email-not-verified'); ?>">
<input type="hidden" class="msg_pass_sent_email" value="<?php echo trans('password-sent-to-email'); ?>">
<input type="hidden" class="msg_pass_reset_succ" value="<?php echo trans('password-reset-successfully'); ?>">
<input type="hidden" class="msg_not_valid_user" value="<?php echo trans('not-a-valid-user'); ?>">
<input type="hidden" class="msg_your_accoun_verified_successfully" value="<?php echo trans('your-account-verified-successfully'); ?>">

<input type="hidden" class="msg_apptype_is_required" value="<?php echo trans('appointment-type-is-required'); ?>">
<input type="hidden" class="msg_booking_date_required" value="<?php echo trans('booking-date-is-required'); ?>">
<input type="hidden" class="msg_booking_time_required" value="<?php echo trans('booking-time-is-required'); ?>">
<input type="hidden" class="msg_processing" value="<?php echo trans('processing'); ?>">
<input type="hidden" class="msg_app_booked_successfully" value="<?php echo trans('appointment-booked-successfully'); ?>">
<input type="hidden" class="msg_book_appointment" value="<?php echo trans('book-appointment'); ?>">
<input type="hidden" class="msg_enter_valid_date" value="<?php echo trans('please-enter-a-valid-date'); ?>">
<input type="hidden" class="msg_registared_successfully" value="<?php echo trans('registared-successfully'); ?>">
<input type="hidden" class="msg_preparing_environment" value="<?php echo trans('preparing-environment'); ?>">
<input type="hidden" class="msg_email_resend_successfully" value="<?php echo trans('email-resend-successfully'); ?>">
<input type="hidden" class="msg_signing_in" value="<?php echo trans('signing-in'); ?>">
<input type="hidden" class="msg_register" value="<?php echo trans('register'); ?>">
<input type="hidden" class="msg_verify_code_is_not_matched" value="<?php echo trans('verify-code-is-not-matched'); ?>">
<input type="hidden" class="msg_verify_code" value="<?php echo trans('verify-code'); ?>">


